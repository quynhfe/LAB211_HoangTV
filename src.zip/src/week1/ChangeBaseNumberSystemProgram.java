/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package week1;

/**
 *
 * @author bong
 */
public class ChangeBaseNumberSystemProgram {
    public  String convertInputToDecimal (String inputValue, int inputBase, int outputBase) {
        try {
            int decimalValue;
            if (inputBase == 1) { 
                decimalValue = Integer.parseInt(inputValue, 2);
            } else if (inputBase == 2) { 
                decimalValue = Integer.parseInt(inputValue);
            } else { 
                decimalValue = Integer.parseInt(inputValue, 16);
            }

            
            if (outputBase == 1) { 
                return Integer.toBinaryString(decimalValue);
            } else if (outputBase == 2) { 
                return String.valueOf(decimalValue);
            } else { 
                return Integer.toHexString(decimalValue).toUpperCase();
            }
        } catch (NumberFormatException e) {
            return null; 
        }
    }
}
