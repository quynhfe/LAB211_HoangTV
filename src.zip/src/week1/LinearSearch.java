/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package week1;

import java.util.Random;


/**
 *
 * @author bong
 */
public class LinearSearch {
    
    public int[] inputArray( int number){
        int[] arr = new int[number];
        for( int i= 0; i< number; i++){
            arr[i]= new Random().nextInt(number);
        }
        return arr;
    }
    
    public void outputArray(int[] arr, int number){
        for(int i = 0; i< number; i++){
            System.out.print(arr[i]);
            if(i != number - 1){
                System.out.print(" ,");
            }
        }
    }

    public void linearSearch(int[] arr, int valueSearch, int number) {
        int k = 0;
        for (int i = 0; i < number; i++) {
            if (arr[i] == valueSearch) {
                System.out.println("Found " + valueSearch + " at index: " + i);
                k++;
            }
        }
        if (k == 0) {
            System.out.println("Coudn't find the value in array...\n");
        }
    }
    
}
